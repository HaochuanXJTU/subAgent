#! /usr/bin/python
# coding=utf-8

import os
import sys

os.popen('/usr/local/net-snmp/bin/localRoute.sh '+'127.0.0.1')
tmpRoute='/tmp/localRoute'
tmpLink='/tmp/linkQuality'


fileLink=open(tmpLink,'w')
fileLink.truncate()
fileRoute=open(tmpRoute,'r')
str=''
for line in fileRoute:
	list=line.split()
	if (list[1]=='0.0.0.0') and (list[2]=='255.255.255.255'):
		str+=list[0]
		pipe=os.popen('/usr/local/net-snmp/bin/testNeighbor '+list[0])
		re=pipe.read()
		list2=re.split()
		for i in range(len(list2)):
			str+='\t'+list2[i]
		str+='\n'
fileLink.write(str)
fileLink.close()
fileRoute.close()
